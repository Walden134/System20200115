package org.sang.bean.flood;

public class P3 {
	private double p;
	private double cs;
	private double fai;
	private String id;

	public double getP() {
		return p;
	}

	public void setP(double p) {
		this.p = p;
	}

	public double getCs() {
		return cs;
	}

	public void setCs(double cs) {
		this.cs = cs;
	}

	public double getFai() {
		return fai;
	}

	public void setFai(double fai) {
		this.fai = fai;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
