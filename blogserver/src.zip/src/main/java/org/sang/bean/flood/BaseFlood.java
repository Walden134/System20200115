package org.sang.bean.flood;

public class BaseFlood {
	private int id;
	private int year;
	private double q;
	private double w1;
	private double w3;
	private double w7;
	private double w15;
	private double p;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public double getQ() {
		return q;
	}

	public void setQ(double q) {
		this.q = q;
	}

	public double getW1() {
		return w1;
	}

	public void setW1(double w1) {
		this.w1 = w1;
	}

	public double getW3() {
		return w3;
	}

	public void setW3(double w3) {
		this.w3 = w3;
	}

	public double getW7() {
		return w7;
	}

	public void setW7(double w7) {
		this.w7 = w7;
	}

	public double getW15() {
		return w15;
	}

	public void setW15(double w15) {
		this.w15 = w15;
	}

	public double getP() {
		return p;
	}

	public void setP(double p) {
		this.p = p;
	}
}
