package org.sang.bean.flood;

public class BaseP {
	 private int id;
	 private double objP;
	 private double cnrmP;
	 private double mirocP;
	 private double canesmP;
	 private double gfdlP;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getObjP() {
		return objP;
	}
	public void setObjP(double objP) {
		this.objP = objP;
	}
	public double getCnrmP() {
		return cnrmP;
	}
	public void setCnrmP(double cnrmP) {
		this.cnrmP = cnrmP;
	}
	public double getMirocP() {
		return mirocP;
	}
	public void setMirocP(double mirocP) {
		this.mirocP = mirocP;
	}
	public double getCanesmP() {
		return canesmP;
	}
	public void setCanesmP(double canesmP) {
		this.canesmP = canesmP;
	}
	public double getGfdlP() {
		return gfdlP;
	}
	public void setGfdlP(double gfdlP) {
		this.gfdlP = gfdlP;
	}
}
