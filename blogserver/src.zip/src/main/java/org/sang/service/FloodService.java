package org.sang.service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.sang.bean.flood.BaseFlood;
import org.sang.bean.flood.BaseP;
import org.sang.bean.flood.FloodRisk;
import org.sang.bean.flood.FutureP;
import org.sang.bean.flood.GeneralFlood;
import org.sang.bean.flood.P3;
import org.sang.bean.flood.UncertainP;
import org.sang.bean.hydro.DoubleCurve;
import org.sang.mapper.FloodMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;

@Service
@Transactional
public class FloodService {
	@Autowired
	FloodMapper floodMapper;

	public Map<String, Object> drawLine(GeneralFlood generalFlood) {
		Map<String, Object> map = new HashMap<>();
		double ex = generalFlood.getEx();
		double cv = generalFlood.getCv();
		double cs = generalFlood.getCs();// 2.536
		if (ex == 0 & cv == 0 & cs == 0) {
			System.out.println("请输入正确参数值");
			return null;
		}
		DecimalFormat df2 = new DecimalFormat("#.00");
		DecimalFormat df1 = new DecimalFormat("#.0");
		double cs1 = getDouble(cs, 1);
		List<P3> p31 = floodMapper.getPByCs(cs1);// 2.5
		List<P3> p311 = floodMapper.getPByCs(Double.parseDouble(df1.format(cs1 + 0.1)));// 2.6
		int len = p31.size();
		double[] p = new double[len];
		double[] fai = new double[len];
		for (int i = 0; i < len; i++) {
			p[i] = p31.get(i).getP();
			fai[i] = p31.get(i).getFai() + (p311.get(i).getFai() - p31.get(i).getFai()) * (cs - cs1);
		}
		double[][] theoryFrequency = generalFlood.getTheoryFrequency(p, fai);
		map.put("theoryFrequency", theoryFrequency);
		map.put("fitError", generalFlood.getFitError());
		return map;
	}

	/**
	 * a为一个带有未知位小数的实数 对其取b位小数
	 */
	public double getDouble(double a, int b) {
		int x = 0;
		int y = 1;
		for (int i = 0; i < b; i++) {
			y = y * 10;
		}
		x = (int) (a * y);
		return (double) x / y;
	}

	public Map<String, Object> paramEst(GeneralFlood generalFlood) {
		double[] obs = generalFlood.getMesureData();
		double N = generalFlood.getN();
		int a = generalFlood.getA();
		int l = generalFlood.getL();
		if (obs.length < 1 & N == 0 & a == 0 & l == 0) {
			return null;
		}
		generalFlood.CalcParams();
		Map<String, Object> map = new HashMap<>();
		DecimalFormat df = new DecimalFormat("#.00");
		map.put("ex", Double.parseDouble(df.format(generalFlood.getEx())));
		map.put("cv", Double.parseDouble(df.format(generalFlood.getCv())));
		map.put("cs", Double.parseDouble(df.format(generalFlood.getCs())));
		map.put("fitError", generalFlood.getFitError());
		return map;
	}

	public Map<String, Object> getExpFrequency(GeneralFlood generalFlood) {
		double[] obs = generalFlood.getMesureData();
		double N = generalFlood.getN();
		int a = generalFlood.getA();
		int l = generalFlood.getL();
		double[][] expFrequency = generalFlood.getExpFrequency(obs, N, a, l);
		Map<String, Object> map = new HashMap<>();
		map.put("expFrequency", expFrequency);
		return map;
	}

	public Map<String, Object> readBaseP(UncertainP time) {
		List<double[]> bmaP = time.getObjP();
		List<double[]> futurePList = getFuturePList(time.getPattern());
		double[][] q = time.getBMAP(bmaP, futurePList);
		Map<String, Object> map = new HashMap<>();
		double[][] data = new double[2][q.length];
		for (int i = 0; i < q.length; i++) {// 80
			data[0][i] = q[i][4];
			data[1][i] = q[i][94] - q[i][4];
		}
		map.put("q", data);
		return map;
	};

	public Map<String, Object> calcRisk(FloodRisk floodRisk) {
		List<double[]> typicalFloods = floodRisk.getTypicalFloods();
		DoubleCurve levelCapacityCurve = new DoubleCurve(floodRisk.getLevelCapacityCurve().getCurveData());
		DoubleCurve leveldownOutflowCurve = new DoubleCurve(floodRisk.getLeveldownOutflowCurve().getCurveData());
		floodRisk.setLevelCapacityCurve(levelCapacityCurve);
		floodRisk.setLeveldownOutflowCurve(leveldownOutflowCurve);
		String baseFloodJson = getBaseFlood();
		List<double[]> basePList = getBasePList();
		List<double[]> futurePList = getFuturePList(floodRisk.getPattern());
		List<double[]> riskRes = floodRisk.getRiskRes(typicalFloods, baseFloodJson, basePList, futurePList);
		Map<String, Object> map = new HashMap<>();
		map.put("riskRes", riskRes);
		return map;
	}

	private String getBaseFlood() {
		List<BaseFlood> baseFloodList = floodMapper.getBaseFlood();
		double[][] baseFlood = new double[baseFloodList.size()][7];
		for (int i = 0; i < baseFloodList.size(); i++) {
			BaseFlood flood = baseFloodList.get(i);
			baseFlood[i][0] = flood.getYear();
			baseFlood[i][1] = flood.getQ();
			baseFlood[i][2] = flood.getW1();
			baseFlood[i][3] = flood.getW3();
			baseFlood[i][4] = flood.getW7();
			baseFlood[i][5] = flood.getW15();
			baseFlood[i][6] = flood.getP();
		}
		return JSON.toJSONString(baseFlood);
	}

	private List<double[]> getFuturePList(String rcpId) {
		List<FutureP> futurePList = floodMapper.getFuturePByRcp(rcpId);
		List<double[]> list = new ArrayList<double[]>();
		double[] cnrmP = new double[futurePList.size()];
		double[] canesmP = new double[futurePList.size()];
		double[] mirocP = new double[futurePList.size()];
		double[] gfdlP = new double[futurePList.size()];
		for (int i = 0; i < futurePList.size(); i++) {
			FutureP futureP = futurePList.get(i);
			cnrmP[i] = futureP.getCnrmP();
			canesmP[i] = futureP.getCanesmP();
			mirocP[i] = futureP.getMirocP();
			gfdlP[i] = futureP.getGfdlP();
		}
		list.add(cnrmP);
		list.add(canesmP);
		list.add(mirocP);
		list.add(gfdlP);
		return list;
	}

	private List<double[]> getBasePList() {
		List<BaseP> basePList = floodMapper.getBaseP();
		List<double[]> list = new ArrayList<double[]>();
		double[] objP = new double[basePList.size()];
		double[] cnrmP = new double[basePList.size()];
		double[] canesmP = new double[basePList.size()];
		double[] mirocP = new double[basePList.size()];
		double[] gfdlP = new double[basePList.size()];
		for (int i = 0; i < basePList.size(); i++) {
			BaseP baseP = basePList.get(i);
			objP[i] = baseP.getObjP();
			cnrmP[i] = baseP.getCnrmP();
			canesmP[i] = baseP.getCanesmP();
			mirocP[i] = baseP.getMirocP();
			gfdlP[i] = baseP.getGfdlP();
		}
		list.add(objP);
		list.add(cnrmP);
		list.add(canesmP);
		list.add(mirocP);
		list.add(gfdlP);
		return list;
	};
}
