<template>
  <div style="width:100%">
    <el-form :inline="true" :model="formData" class="demo-form-inline" :label-position="labelPosition" size="small">
      <div class="run_mark">图层导入</div>
      <div class="input">
        <div>
          <label class="run_label" for="" style="width:68px">DEM</label>
          <upload_excel :fileList="DEM" @func="getDEM">
          </upload_excel>
        </div>
        <div>
          <label class="run_label" for="">土地利用</label>
          <upload_excel :fileList="landuse" @func="getLanduse">
          </upload_excel>
        </div>
        <div>
          <label class="run_label" for="">土壤类型</label>
          <upload_excel :fileList="soil" @func="getSoil">
          </upload_excel>
        </div>
        <div>
          <label class="run_label" for="">站点分布</label>
          <upload_excel :fileList="site" @func="getSite">
          </upload_excel>
        </div>
      </div>

      <div class="run_mark">数据输入</div>
      <div class="input">
        <div>
          <label class="run_label" for="" style="width:68px">气温</label>
          <upload_excel :fileList="temperature" @func="getTemperature">
          </upload_excel>
        </div>
        <div>
          <label class="run_label" for="" style="width:68px">降水</label>
          <upload_excel :fileList="precipitation" @func="getPrecipitation">
          </upload_excel>
        </div>
        <div>
          <label class="run_label" for="" style="width:68px">径流</label>
          <upload_excel :fileList="runoff" @func="getRunoff">
          </upload_excel>
        </div>
      </div>

      <div class="run_mark">方案设置</div>
      <div class="input">
        <label class="run_label" for="">参数方案</label>
        <upload_excel :fileList="paramsPlan" @func="getParamsPlan">
        </upload_excel>
        <!-- <el-form-item label="断面选择" label-width="" style="margin-bottom: 1px;" v-model="hydrostation.levelDead"> -->

        <label class="run_label" for="">断面选择</label>
        <div style="margin-bottom: 1px; ">
          <el-select style=" width:95px" v-model="hydrostation.sectionSelect">
            <el-option label="雅江" value="雅江"></el-option>
            <el-option label="洼里" value="洼里"></el-option>
            <el-option label="小得石" value="小得石"></el-option>
            <el-option label="麦地龙" value="麦地龙"></el-option>
          </el-select>
        </div>

        <!-- </el-form-item> -->
        <label class="run_label" for="">计算时段</label>
        <div style="margin-bottom: 1px; ">
          <el-select style=" width:95px" v-model="calculateBean.calculatePeriod">
            <el-option label="日" value="日"></el-option>
            <el-option label="月" value="月"></el-option>
          </el-select>
        </div>
        <!-- <el-form-item label="计算时段" style="margin-bottom: 1px; "> -->

        <!-- </el-form-item> -->
        <label class="run_label" for="">情景选择</label>
        <div style="margin-bottom: 1px; ">
          <el-select style=" width:95px" v-model="calculateBean.sceneSelect">
            <el-option label="RCP2.6" value="RCP2.6"></el-option>
            <el-option label="RCP4.5" value="RCP4.5"></el-option>
            <el-option label="RCP8.5" value="RCP8.5"></el-option>
          </el-select>
        </div>
        <!-- <el-form-item label="情景选择" style="margin-bottom: 1px; "> -->
        <!-- </el-form-item> -->

        <!-- <label class="run_label" for="">方案名称</label>
        <div style="margin-bottom: 1px; ">
          <el-input style=" width:80px" v-model="hydrostation.levelDead"></el-input>
        </div> -->

        <!-- <el-form-item label="方案名称" style="margin-bottom: 1px; "> -->
        <!-- </el-form-item> -->
        <!-- <el-checkbox-group v-model="checkedPatterns" @change="handleCheckedPatternsChange" :min="1" size="medium">
          <el-checkbox v-for="pattern in patterns" :label="pattern" :key="pattern" border></el-checkbox>
        </el-checkbox-group> -->
      </div>

      <el-form-item style="margin-top: 10px;margin-bottom: 0px">
        <el-button type="primary" @click.native.prevent="submitClick">开始计算</el-button>
        <el-button>保存</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import UploadExcel from "@/components/UploadExcel";
import { getRequest } from "../../utils/api";
import { putRequest } from "../../utils/api";
import { postRequest1 } from "../../utils/api";
import { postRequest } from "../../utils/api";
const patternOptions = [];
const situationOptions = ["GFDL", "CNRM", "CanESM", "MIROC", "BMA"];

export default {
  name: "inputData",
  props: {},
  data() {
    return {
      // levelCapacityCurve: [{ name: "水位库容关系.xlsx", url: "" }],
      // leveldownOutflowCurve: [{ name: "尾水流量关系.xlsx", url: "" }],
      // headlossOutflowCurve: [{ name: "水头损失曲线.xlsx", url: "" }],
      // expectOutputHeadCurve: [{ name: "出力限制曲线.xlsx", url: "" }],
      // levelCapacityCurve: [],
      // leveldownOutflowCurve: [],
      // headlossOutflowCurve: [],
      // expectOutputHeadCurve: [],
      // checkedPatterns: ["Base"],
      // patterns: patternOptions,
      // checkedSituations: ["GFDL", "CNRM", "CanESM", "MIROC", "BMA"],
      // situations: situationOptions,
      // labelPosition: "left",
      // formData: {},
      hydrostation: {
        // id: "1",
        // name: "杨房沟",
        sectionSelect: ""
        // levelDead: "2088",
        // levelNormal: "2094",
        // outflowMax: "15200",
        // outflowMin: "0",
        // installPower: 1500,
        // levelCapacityCurve: { curveData: [] },
        // leveldownOutflowCurve: { curveData: [] },
        // headlossOutflowCurve: { curveData: [] },
        // expectOutputHeadCurve: { curveData: [] },
        // outputCoefficient: "8.5",
        // outputDesign: "176",
        // avgDesiginPower: "59.62"
      },
      calculateBean: {
        calculatePeriod: "",
        sceneSelect: ""
        // situations: ["GFDL", "CNRM", "CanESM", "MIROC", "BMA"],
        // patterns: ["Base"],
        // levelBegin: "2094",
        // levelEnd: "2094"
        // deltaT: 1
      }
    };
  },
  components: {
    upload_excel: UploadExcel
  },
  methods: {
    // getLevelCapacityCurve(data) {
    //   let i = 0;
    //   data.map(val => {
    //     this.hydrostation.levelCapacityCurve.curveData[i] = [];
    //     this.hydrostation.levelCapacityCurve.curveData[i] = [];
    //     this.hydrostation.levelCapacityCurve.curveData[i][0] = val["水位"];
    //     this.hydrostation.levelCapacityCurve.curveData[i][1] = val["库容"];
    //     i++;
    //   });
    // },
    // getHeadlossOutflowCurve(data) {
    //   let i = 0;
    //   data.map(val => {
    //     this.hydrostation.headlossOutflowCurve.curveData[i] = [];
    //     this.hydrostation.headlossOutflowCurve.curveData[i] = [];
    //     this.hydrostation.headlossOutflowCurve.curveData[i][0] = val["距离"];
    //     this.hydrostation.headlossOutflowCurve.curveData[i][1] =
    //       val["水头损失"];
    //     i++;
    //   });
    // },
    // getLeveldownOutflowCurve(data) {
    //   let i = 0;
    //   data.map(val => {
    //     this.hydrostation.leveldownOutflowCurve.curveData[i] = [];
    //     this.hydrostation.leveldownOutflowCurve.curveData[i] = [];
    //     this.hydrostation.leveldownOutflowCurve.curveData[i][0] = val["水位"];
    //     this.hydrostation.leveldownOutflowCurve.curveData[i][1] =
    //       val["下泄流量"];
    //     i++;
    //   });
    // },
    // getExpectOutputHeadCurve(data) {
    //   let i = 0;
    //   data.map(val => {
    //     this.hydrostation.expectOutputHeadCurve.curveData[i] = [];
    //     this.hydrostation.expectOutputHeadCurve.curveData[i] = [];
    //     this.hydrostation.expectOutputHeadCurve.curveData[i][0] = val["水头"];
    //     this.hydrostation.expectOutputHeadCurve.curveData[i][1] =
    //       val["最大出力"];
    //     i++;
    //   });
    // },

    // handleCheckedPatternsChange(value) {
    //   this.calculateBean.patterns = value;
    //   // this.$emit("patterns", value);
    //   bus.$emit("patterns", value);
    // },
    // handleCheckedSituationsChange(value) {
    //   this.calculateBean.situations = value;
    //   // this.$emit("situations", value);
    //   bus.$emit("situations", value);
    // },

    submitClick: function() {
      var _this = this;

      getRequest(
        "/power/submit" +
          "?hydrostation=" +
          JSON.stringify(_this.hydrostation) +
          "&calculateBean=" +
          JSON.stringify(_this.calculateBean)
      ).then(
        resp => {
          if (resp.status == 200) {
            //成功
            _this.$store.commit("flag", true);
            bus.$emit("xAxis", resp.data.xAxis);
            bus.$emit("powerList", resp.data.powerList);
            bus.$emit("outputList", resp.data.outputList);
            _this.$alert("计算成功!", "成功!");
          } else {
            //失败
            _this.$alert("计算失败!", "失败!");
          }
        },
        resp => {
          _this.$alert("找不到服务器⊙﹏⊙∥!", "失败!");
        }
      );
    }
  }
  // created() {
  //   bus.$emit("patterns", this.checkedPatterns);
  //   bus.$emit("situations", this.checkedSituations);
  //   bus.$emit("avgDesiginPower", this.hydrostation.avgDesiginPower);
  //   bus.$emit("outputDesign", this.hydrostation.outputDesign);
  // },
  // watch: {
  //   hydrostation: {
  //     handler: function() {
  //       bus.$emit("avgDesiginPower", this.hydrostation.avgDesiginPower);
  //       bus.$emit("outputDesign", this.hydrostation.outputDesign);
  //     },
  //     deep: true
  //   }
  // }
};
</script>
<style>
.el-checkbox + .el-checkbox {
  margin: 0px;
}
.el-checkbox.is-bordered + .el-checkbox.is-bordered {
  margin-right: 10px;
}
.el-checkbox {
  width: 100px;
  margin: 10px 10px 2px 10px;
}
.run_mark {
  font: 19px "Microsoft YaHei";
  position: relative;
  top: 10px;
  right: -13px;
  width: 100px;
  z-index: 10;
  border-radius: 5px;
  background-color: blue;
  color: white;
}
.input > div {
  height: 40px;
}
.input {
  border: 2px solid rgba(74, 136, 220, 0.996078431372549);
  padding: 8px;
}
.run_label {
  text-align: right;
  vertical-align: middle;
  float: left;
  font-size: 14px;
  color: #606266;
  line-height: 40px;
  padding: 0 12px 0 0;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
</style>
