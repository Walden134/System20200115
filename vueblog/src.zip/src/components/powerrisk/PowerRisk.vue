<template>
  <el-container class="powerrisk">
    <el-main class="main">
      <el-tabs v-model="activeName" @tab-click="handleClick" type="card">
        <div class="pane" style=" width:270px">
          <powerRiskInputData></powerRiskInputData>
          <!-- <powerRiskInputData  @situations="getSituations" @patterns="getPatterns"></powerRiskInputData> -->
        </div>
        <div class="powerrisk_top">

          <powerRiskcChart :title="chuliquxian" :request="powerRequest" style="width:100%;height:100%">
          </powerRiskcChart>
        </div>
        <div class="powerrisk_bottom">
          <div>
            <powerRiskTable :title="outputTitle" style="width:100%;height:100%"></powerRiskTable>
          </div>
          <div>
            <outputRiskTable :title="powerTitle" style="width:100%;height:100%"></outputRiskTable>
          </div>
        </div>
      </el-tabs>
    </el-main>
  </el-container>
</template>
<script>
import PowerRiskTable from "@/components/powerrisk/PowerRiskTable";
import OutputRiskTable from "@/components/powerrisk/OutputRiskTable";
import PowerRiskCharts from "@/components/powerrisk/PowerRiskCharts";
import PowerRiskInputData from "@/components/powerrisk/PowerRiskInputData";
import ECharts from "vue-echarts/components/ECharts.vue";
import "echarts/lib/chart/line";
import "echarts/lib/component/tooltip";
import "echarts/lib/component/polar";
import "echarts/lib/component/legend";
import "echarts/lib/component/title";
import "echarts/theme/dark";
import "echarts/lib/chart/bar";
import { postRequest } from "../../utils/api";
import { putRequest } from "../../utils/api";
import { deleteRequest } from "../../utils/api";
import { getRequest } from "../../utils/api";
export default {
  data() {
    return {
      activeName: "post",
      isAdmin: false,
      chuliquxian: {
        title: "出力保证率曲线图"
      },
      outputTitle: {
        title: "发电量风险率",
        label1: "情景",
        label2: "相对典型枯水年风险率",
        label3: "相对设计多年平均风险率"
      },
      powerTitle: {
        title: "保证出力风险率",
        label1: "情景",
        label2: "176.0MW对应保证率",
        label3: "风险率"
      },
      outputRequest: "/article/dataStatistics",
      powerRequest: "/article/dataStatistics"
    };
  },
  components: {
    powerRiskInputData: PowerRiskInputData,
    powerRiskcChart: PowerRiskCharts,
    chart: ECharts,
    powerRiskTable: PowerRiskTable,
    outputRiskTable: OutputRiskTable
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    getRequestData() {
      var _this = this;
      getRequest("/isAdmin").then(resp => {
        if (resp.status == 200) {
          _this.isAdmin = resp.data;
        }
      });
      getRequest("/article/dataStatistics").then(
        resp => {
          if (resp.status == 200) {
            _this.output = resp.data;
          } else {
            _this.$message({ type: "error", message: "数据加载失败!" });
          }
        },
        resp => {
          _this.$message({ type: "error", message: "数据加载失败!" });
        }
      );
      getRequest("/article/dataStatistics").then(
        resp => {
          if (resp.status == 200) {
            _this.power = resp.data;
          } else {
            _this.$message({ type: "error", message: "数据加载失败!" });
          }
        },
        resp => {
          _this.$message({ type: "error", message: "数据加载失败!" });
        }
      );
    }
  },
  mounted() {
    this.getRequestData();
  }
};
</script>
<style>
.powerrisk_top {
  width: 33%;
  height: 400px;
  background-color: aliceblue;
  float: left;
  margin: 10px 5px;
}
.powerrisk_bottom > div {
  width: calc((100% - 300px) / 2);
  height: 310px;
  background-color: aliceblue;
  float: left;
  margin: 10px 5px;
}
</style>
