export default {
  patterns: [],
  situations: [],
  flag: false,
}