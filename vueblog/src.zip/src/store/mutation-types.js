

export const SITUATIONS = 'situations'
export const PATTERNS = 'patterns'
export const FLAG = 'flag'




